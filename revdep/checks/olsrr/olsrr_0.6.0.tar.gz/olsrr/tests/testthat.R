library(testthat)
library(olsrr)

test_check("olsrr")
