# output from all subsets regression is as expected

    Code
      ols_step_all_possible(model)
    Output
        Index N Predictors  R-Square Adj. R-Square Mallow's Cp
      1     1 1       disp 0.7183433     0.7089548   0.6751205
      2     2 1         hp 0.6024373     0.5891853   0.5096958
      3     3 2    disp hp 0.7482402     0.7308774   0.6945438

