# output from ols_correlations is as expected

    Code
      ols_correlations(model)
    Output
                     Correlations                 
      -------------------------------------------
      Variable    Zero Order    Partial     Part  
      -------------------------------------------
      disp            -0.848      0.048     0.019 
      hp              -0.776     -0.224    -0.093 
      wt              -0.868     -0.574    -0.285 
      qsec             0.419      0.219     0.091 
      -------------------------------------------

