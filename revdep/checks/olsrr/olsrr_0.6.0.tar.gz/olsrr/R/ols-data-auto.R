#' Test Data Set
#' @keywords internal
"auto"
