#' Test Data Set
#' @keywords internal
"hsb"
