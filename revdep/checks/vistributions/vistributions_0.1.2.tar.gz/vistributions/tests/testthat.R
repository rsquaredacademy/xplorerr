library(testthat)
library(vistributions)

test_check("vistributions")
