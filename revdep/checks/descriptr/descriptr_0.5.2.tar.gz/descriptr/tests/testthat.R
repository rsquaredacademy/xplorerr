library(testthat)
library(descriptr)

test_check("descriptr")
