#' mtcarz
#'
#' Copy of mtcars data set with modified variable types
#'
"mtcarz"
